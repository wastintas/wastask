"""
Stack Definition Agent for automatic technology recommendation
"""