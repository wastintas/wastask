"""GitHub integration agent module."""
