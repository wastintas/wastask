"""Agents module for Wastask."""
