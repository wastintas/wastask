"""Coordinator agent module."""
