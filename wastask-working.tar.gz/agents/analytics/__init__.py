"""Analytics agent module."""
