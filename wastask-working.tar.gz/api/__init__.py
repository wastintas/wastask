"""API module for Wastask."""
