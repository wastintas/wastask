"""CLI module for Wastask."""
