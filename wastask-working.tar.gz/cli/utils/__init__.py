"""CLI utilities module."""
