"""Tools module for Wastask."""
