"""Configuration module for Wastask."""
