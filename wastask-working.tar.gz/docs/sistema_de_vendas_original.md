# Sistema de Vendas - Original PRD

# Sistema de Vendas

Preciso de um sistema para gerenciar vendas da empresa.

## O que precisa ter:
- Cadastro de clientes
- Cadastro de produtos  
- Fazer vendas
- Ver relatórios

Deve ser web e fácil de usar.

Budget: R$ 20.000
Prazo: 3 meses