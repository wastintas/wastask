"""Core module for Wastask."""
