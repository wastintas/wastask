"""Tests module for Wastask."""
